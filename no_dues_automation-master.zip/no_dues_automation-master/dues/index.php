<?php
	header('Location: dues.php');
?>