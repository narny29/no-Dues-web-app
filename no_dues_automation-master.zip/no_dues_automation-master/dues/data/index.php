<?php
header('Location: editUsers.php');
?>